# atomix.js
Atomix is a puzzle game. On each level, you are given a couple of atoms, and your task is to arrange them into a specific molecule.

http://josteintopland.github.io/atomix.js